package ete.pirepositorio;

import ete.negocios.Funcion�rio;
import ete.banco.ConexaoBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class RepFuncionario { //senha com md5 n�o aparece no bd!!
    
    Connection con;
    
    public boolean inserir(Funcion�rio funcion�rio) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        
        String sql = "insert into funcionarios (no_funcionario, cpf, senha, cargo, data_nasc) values "
                + "(?,?,md5(?),?,?)";
    try{
        con.setAutoCommit(false);
        PreparedStatement stmt = con.prepareStatement(sql);
        
        stmt.setString(1, funcion�rio.getNome());
        stmt.setString(2, funcion�rio.getCpf());
        stmt.setString(3, funcion�rio.getSenha());
        stmt.setString(4, funcion�rio.getCargo());
        java.util.Date data = funcion�rio.getData_nascimento();
        stmt.setDate(5, new java.sql.Date(data.getTime()));

        
        stmt.executeUpdate();
        con.commit();
        JOptionPane.showMessageDialog(null, "Funcion�rio salvo");
        ConexaoBanco.fecharConexao(con);
        
     }catch (Exception ex){
         try{
             con.rollback();
             JOptionPane.showMessageDialog(null, "Erro ao inserir funcion�rio");
             return false;
         }catch(SQLException exSql){
             System.err.println(exSql.getMessage());
         }
     }
    return true;
    }
    
    public List<Funcion�rio> retornar() throws SQLException{
        con = (Connection )ConexaoBanco.conectar();
        List<Funcion�rio> funcion�rios = new ArrayList<>();
        
        String sql = "select * from funcionarios order by id desc";
        
        try{
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                
                Funcion�rio funcion�rio = new Funcion�rio();
                
                funcion�rio.setId(rs.getInt("id_funcionario"));
                funcion�rio.setNome(rs.getString("no_funcionario"));
                funcion�rio.setCpf(rs.getString("senha"));
                funcion�rio.setData_nascimento(rs.getDate("data_nasc"));
                funcion�rio.setCargo(rs.getString("cargo"));
                
            }
        }catch(SQLException ex){
            return null;
            
        }finally{
        ConexaoBanco.fecharConexao(con);
    }
           return funcion�rios;
    }
    //pesquisa cpf
    public Funcion�rio achar(String cpf)throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        Funcion�rio funcion�rio = null;
        
        String sql = "select * from funcionarios where cpf = ?";
        
        try{
            
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()){
                funcion�rio.setId(rs.getInt("id_funcionario"));
                funcion�rio.setCpf(rs.getString("cpf"));
                funcion�rio.setNome(rs.getString("no_funcionario"));
                funcion�rio.setData_nascimento(rs.getDate("data_nasc"));
                funcion�rio.setCargo(rs.getString("cargo"));
                funcion�rio.setSenha(rs.getString("senha"));
            }
        }catch(SQLException ex){
            return null;
        }
        return funcion�rio;
    }
    
    public boolean atualizar(Funcion�rio funcion�rio)throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        String sql = "update funcionarios set senha = md5(?) where cpf = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, funcion�rio.getSenha());
            stmt.setString(2, funcion�rio.getCpf());
            
            stmt.executeUpdate();
            
            con.commit();
            
            ConexaoBanco.fecharConexao(con);
            
            return true;
        }catch(SQLException ex){
            try{
                con.rollback();
                System.err.println(ex);
                return false;
            }catch(SQLException ex1){
                System.err.println(ex1);
            }
        }
        return false;
    }
    
    public boolean excluir (int id)throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        String sql = "delete from funcionarios where id = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            
            stmt.setInt(1, id);
            
            int linhasAfetadas = stmt.executeUpdate();
            con.commit();
            ConexaoBanco.fecharConexao(con);
            
            return linhasAfetadas>0;
            
        }catch(SQLException ex){
            return false;
            
        }
    }
    
    public int login(String cpf, String senha) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        int ret=0;
        
        String sql = "Select count(*) as total from funcionarios where cpf = ? and senha = ?";
        
        try{
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery(sql);
            
            while(rs.next()){
                ret = rs.getInt("total");
            }
        }catch(SQLException ex){
            return ret;
        }
        return ret;
    }
}

