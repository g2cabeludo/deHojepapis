
package ete.pirepositorio;


import ete.banco.ConexaoBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import ete.negocios.Produto;

public class RepProduto {
    Connection con;
    
    public RepProduto(){
        
    }
    public void reduzirEstoque(int idProduto, int quantidade) throws SQLException {
    Connection con = ConexaoBanco.conectar();
    String sql = "UPDATE produto SET quantidade = quant_prod - ? WHERE id_produto = ?";
    PreparedStatement stmt = con.prepareStatement(sql);
    stmt.setInt(1, quantidade);
    stmt.setInt(2, idProduto);
    stmt.executeUpdate();
    stmt.close();
    con.close();
}

    
    public boolean inserir (Produto produto) throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        
        String sql = "insert into produto (no_produto, descricao, quant_prod,"
                + "preco) values (?,?,?,?)";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            
            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getDescricao());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setDouble(4, produto.getPreco());
            
            stmt.executeUpdate();
            con.commit();
            JOptionPane.showMessageDialog(null, "Produto cadastrado");
            ConexaoBanco.fecharConexao(con);
            
            return true;

        }catch(Exception ex){
            if(con!=null){
            try{
             con.rollback();
             JOptionPane.showMessageDialog(null, "Erro ao inserir Produto");
             return false;
         }catch(SQLException exSql){
             System.err.println(exSql.getMessage());
         }
            }
         return false;   
     }finally{
            ConexaoBanco.fecharConexao(con);
        }
    }
    
    public List<Produto> retornar() throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        List<Produto> produtos = new ArrayList<>();
        
        String sql = "select * from produto order by id_produto desc";
        
        try{
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Produto produto = new Produto();
                produto.setId(rs.getInt("id_produto"));
                produto.setNome(rs.getString("no_produto"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setQuantidade(rs.getInt("quant_prod"));
                produto.setPreco(rs.getDouble("preco"));
                
                produtos.add(produto);
            }
        }catch(SQLException ex){
            return null;
        }finally{
            ConexaoBanco.fecharConexao(con);
        }
        return produtos;
    }
    
    public List<Produto> Achar(String nome) throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        List<Produto> produtos= new ArrayList<>();
        
        String sql = "select * from produto where no_produto like ?";
        
        try{
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Produto produto = new Produto();
                
                produto.setNome(rs.getString("no_produto"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setQuantidade(rs.getInt("quant_prod"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setId(rs.getInt("id_produto"));
                
                produtos.add(produto);
            }  
        }catch(SQLException ex){
            return null;
        }finally{
            ConexaoBanco.fecharConexao(con);
        }
        return produtos;
    }
    
    public boolean atualizar(Produto produto)throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        String sql = "update produto set no_produto = ? , descricao = ?, quant_prod = ?, preco = ? where id_produto = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getDescricao());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setDouble(4, produto.getPreco());
            stmt.setInt(5, produto.getId());
            
            stmt.executeUpdate();
            
            con.commit();
           
            
            return true;
        }catch(SQLException ex){
            if(con !=null){
            try{
                con.rollback();
                System.err.println(ex);
                return false;
            }catch(SQLException ex1){
                System.err.println(ex1);
            }
        }
             return false;
        }finally{
    ConexaoBanco.fecharConexao(con);
    }
   }
    
    public boolean excluir(int id)throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        String sql = "delete from produto where id_produto = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            
            stmt.setInt(1, id);
            
            int linhasAfetadas = stmt.executeUpdate();
            con.commit();
          
            
            return linhasAfetadas>0;
            
        }catch(SQLException ex){
            if (con != null) {
            try {
                con.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erro no rollback: " + rollbackEx);
            }
        }
        System.err.println("Erro ao excluir produto: " + ex);
        return false;
    } finally  {
            ConexaoBanco.fecharConexao(con);
            
        }
    }
    
    public Produto procurar(int id)throws SQLException{
        con = ConexaoBanco.conectar();
        Produto produto = null;
        
        String sql = "select * from produto where id_produto = ?";
        
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if(rs.next()){
                produto.setId(rs.getInt("id_produto"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setQuantidade(rs.getInt("quant_prod"));
            }
        }finally{
            ConexaoBanco.fecharConexao(con);
        }
        return produto;
    }
 
}
