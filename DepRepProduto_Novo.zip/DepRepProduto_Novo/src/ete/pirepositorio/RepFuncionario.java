package ete.pirepositorio;

import ete.negocios.Funcionario;
import ete.banco.ConexaoBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class RepFuncionario { //senha com md5 n�o aparece no bd!!
    
    Connection con;
    
    public boolean inserir(Funcionario Funcionario) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        
        String sql = "insert into funcionarios (no_funcionario, cpf, senha, cargo, data_nasc) values "
                + "(?,?,md5(?),?,?)";
    try{
        con.setAutoCommit(false);
        PreparedStatement stmt = con.prepareStatement(sql);
        
        stmt.setString(1, Funcionario.getNome());
        stmt.setString(2, Funcionario.getCpf());
        stmt.setString(3, Funcionario.getSenha());
        stmt.setString(4, Funcionario.getCargo());
        java.util.Date data = Funcionario.getData_nascimento();
        stmt.setDate(5, new java.sql.Date(data.getTime()));

        
        stmt.executeUpdate();
        con.commit();
        JOptionPane.showMessageDialog(null, "Funcionario salvo");
        return true;
        
     }catch (Exception ex){
         if(con!=null){
         try{
             con.rollback();
             JOptionPane.showMessageDialog(null, "Erro ao inserir Funcionario");
             return false;
         }catch(SQLException exSql){
             System.err.println(exSql.getMessage());
         }
         }
         return false;
     }finally{
        ConexaoBanco.fecharConexao(con);
    }

    }
    
    public List<Funcionario> retornar() throws SQLException{
        con = (Connection )ConexaoBanco.conectar();
        List<Funcionario> Funcionarios = new ArrayList<>();
        
        String sql = "select * from funcionarios order by id_funcionario desc";
        
        try{
            
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                
                Funcionario Funcionario = new Funcionario();
                
                Funcionario.setId(rs.getInt("id_funcionario"));
                Funcionario.setNome(rs.getString("no_funcionario"));
                Funcionario.setCpf(rs.getString("cpf"));
                Funcionario.setSenha(rs.getString("senha"));
                Funcionario.setData_nascimento(rs.getDate("data_nasc"));
                Funcionario.setCargo(rs.getString("cargo"));
                
                Funcionarios.add(Funcionario);
                
            }
        }catch(SQLException ex){
            return null;
            
        }finally{
        ConexaoBanco.fecharConexao(con);
    }
           return Funcionarios;
    }
    //pesquisa cpf
    public Funcionario achar(String cpf)throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        Funcionario Funcionario = null;
        
        String sql = "select * from funcionarios where cpf = ?";
        
        try{
            
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()){
                Funcionario = new Funcionario();
                
                Funcionario.setId(rs.getInt("id_funcionario"));
                Funcionario.setCpf(rs.getString("cpf"));
                Funcionario.setNome(rs.getString("no_funcionario"));
                Funcionario.setData_nascimento(rs.getDate("data_nasc"));
                Funcionario.setCargo(rs.getString("cargo"));
                Funcionario.setSenha(rs.getString("senha"));
            }
        }catch(SQLException ex){
            System.err.println("Erro ao buscar Funcionario: " + ex.getMessage());
            return null;
        }finally{
            ConexaoBanco.fecharConexao(con);
        }
        return Funcionario;
    }
    
    public boolean atualizar(Funcionario Funcionario)throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        String sql = "update funcionarios set senha = md5(?) where cpf = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, Funcionario.getSenha());
            stmt.setString(2, Funcionario.getCpf());
            
            stmt.executeUpdate();
            
            con.commit();
            
            
            return true;
        }catch(SQLException ex){
            if(con != null){
            try{
                con.rollback();
                System.err.println(ex);
                return false;
            }catch(SQLException ex1){
                System.err.println(ex1);
            }
        }
         return false;
        }finally{
            ConexaoBanco.fecharConexao(con);
        }

    }

    
    public boolean excluir (int id)throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        String sql = "delete from funcionarios where id_funcionario = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            
            stmt.setInt(1, id);
            
            int linhasAfetadas = stmt.executeUpdate();
            con.commit();
            
            return linhasAfetadas>0;
            
        }catch(SQLException ex){
            if (con != null) {
            try {
                con.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erro no rollback: " + rollbackEx);
            }
        }
        System.err.println("Erro ao excluir cliente: " + ex);
        return false;
    } finally  {
            ConexaoBanco.fecharConexao(con);
            
        }
    }
    
    public int login(String cpf, String senha) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        int ret=0;
        
        String sql = "Select count(*) as total from funcionarios where cpf = ? and senha = ?";
        
        try{
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, cpf);
            pstmt.setString(2, senha);
            
            ResultSet rs = pstmt.executeQuery();
            
            while(rs.next()){
                ret = rs.getInt("total");
            }
            rs.close();
            pstmt.close();
        }catch(SQLException ex){
            System.err.println("Erro no login: " + ex.getMessage());
            return ret;
        }finally{
         ConexaoBanco.fecharConexao(con);

        }
        return ret;
    }
    
    public Funcionario procurar(int idFuncionario) throws SQLException {
    Funcionario funcionario = null;
    con = (Connection) ConexaoBanco.conectar();

    String sql = "SELECT * FROM funcionarios WHERE id_funcionario = ?";
    try (PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setInt(1, idFuncionario);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                funcionario = new Funcionario();
                funcionario.setId(rs.getInt("id_funcionario"));
                funcionario.setNome(rs.getString("no_funcionario"));
                funcionario.setCpf(rs.getString("cpf"));
                funcionario.setSenha(rs.getString("senha"));
                funcionario.setCargo(rs.getString("cargo"));
                funcionario.setData_nascimento(rs.getDate("data_nasc"));
            }
        }
    } finally {
        ConexaoBanco.fecharConexao(con);
    }
    return funcionario;
}
}

