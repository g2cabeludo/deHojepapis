package ete.negocios;
import java.util.Date;
import java.util.List;


public class Venda {
    private int id_venda;
    private Cliente cliente;
    private Date data_venda;
    private double valor_total;
    private List<ItemVenda> itens;
    private Funcionario Funcionario;
    
    public Venda(int id_venda, Cliente cliente, Date data_venda, double valor_total, List<ItemVenda> itens, Funcionario Funcionario){
        this.id_venda = id_venda;
        this.cliente = cliente;
        this.data_venda = data_venda;
        this.valor_total = valor_total;
        this.itens = itens;
        this.Funcionario = Funcionario;
    }
    public Venda(){
        
    }

    public int getId_venda() {
        return id_venda;
    }

    public void setId_venda(int id_venda) {
        this.id_venda = id_venda;
    }

    public Funcionario getFuncionario() {
        return Funcionario;
    }

    public void setFuncionario(Funcionario Funcionario) {
        this.Funcionario = Funcionario;
    }

    public int getId() {
        return id_venda;
    }

    public void setId(int id) {
        this.id_venda = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Date getData_venda() {
        return data_venda;
    }

    public void setData_venda(Date data_venda) {
        this.data_venda = data_venda;
    }

    public double getValor_total() {
        return valor_total;
    }

    public void setValor_total(double valor_total) {
        this.valor_total = valor_total;
    }

    public List<ItemVenda> getItens() {
        return itens;
    }

    public void setItens(List<ItemVenda> itens) {
        this.itens = itens;
    }
    
}
