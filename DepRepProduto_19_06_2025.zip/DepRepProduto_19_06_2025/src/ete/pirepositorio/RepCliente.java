package ete.pirepositorio;


import ete.banco.ConexaoBanco;
import ete.negocios.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import ete.piviews.TelaLogin;


public class RepCliente {
    Connection con;
    
    public boolean desativar(int id) throws SQLException{
        con = ConexaoBanco.conectar();
        String sql = "update cliente set ativo = false where id_cliente = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setInt(1, id);
        return stmt.executeUpdate() > 0;
    }
    public boolean ativar (int id) throws SQLException{
        con = ConexaoBanco.conectar();
        String sql = "update cliente set ativo = true where id_cliente = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setInt(1, id);
        return stmt.executeUpdate() > 0;
    }
    
    public boolean inserir(Cliente cliente) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        
        String sql = "insert into cliente (no_cliente, cpf, senha, telefone, data_nasc) values "
                + "(?,?, ?,?,?)";
    try{
        con.setAutoCommit(false);
        PreparedStatement stmt = con.prepareStatement(sql);
        
        stmt.setString(1, cliente.getNome());
        stmt.setString(2, cliente.getCpf());
        stmt.setString(3, cliente.getSenha());
        stmt.setString(4, cliente.getTelefone());
        java.util.Date data = cliente.getData_nascimento();
        stmt.setDate(5, new java.sql.Date(data.getTime()));

        
        stmt.executeUpdate();
        con.commit();
        JOptionPane.showMessageDialog(null, "Cliente salvo");
       
        
        return true;
        
     }catch (Exception ex){
         if(con!=null){
         try{
             con.rollback();
             JOptionPane.showMessageDialog(null, "Erro ao inserir Cliente");
             return false;
         }catch(SQLException exSql){
             System.err.println(exSql.getMessage());
         }
         }
         return false;
     }finally{
        ConexaoBanco.fecharConexao(con);
    }
    }
    
    public List<Cliente> retornar() throws SQLException{
        con = (Connection )ConexaoBanco.conectar();
        List<Cliente> clientes = new ArrayList<>();
        
        String sql = "select * from cliente where ativo = true order by id_cliente desc";
        
        try{
            
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()){
                
                Cliente cliente = new Cliente();
                
                cliente.setId(rs.getInt("id_cliente"));
                cliente.setNome(rs.getString("no_cliente"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setSenha(rs.getString("senha"));
                cliente.setData_nascimento(rs.getDate("data_nasc"));
                cliente.setTelefone(rs.getString("telefone"));
                
               clientes.add(cliente);
                
            }
        }catch(SQLException ex){
            return null;
            
        }finally{
        ConexaoBanco.fecharConexao(con);
    }
           return clientes;
    }
    
    public Cliente achar(String cpf)throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        Cliente cliente = null;
        
        String sql = "select * from cliente where cpf = ?";
        
        try{
            
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();

            if(rs.next()){
                cliente = new Cliente();
                
                cliente.setId(rs.getInt("id_cliente"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setNome(rs.getString("no_cliente"));
                cliente.setData_nascimento(rs.getDate("data_nasc"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setSenha(rs.getString("senha"));
            }
        }catch(SQLException ex){
            System.err.println("Erro ao buscar cliente: " + ex.getMessage());
            return null;
        }finally{
            ConexaoBanco.fecharConexao(con);
        }
        return cliente;
    }
    
    public Cliente procurarId(int id_cliente)throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        Cliente cliente = null;
        
        String sql = "select * from cliente where id_cliente = ?";
        
        try{
            
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, id_cliente);
            ResultSet rs = stmt.executeQuery();

            if(rs.next()){
                cliente = new Cliente();
                
                cliente.setId(rs.getInt("id_cliente"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setNome(rs.getString("no_cliente"));
                cliente.setData_nascimento(rs.getDate("data_nasc"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setSenha(rs.getString("senha"));
            }
        }catch(SQLException ex){
            System.err.println("Erro ao buscar cliente: " + ex.getMessage());
            return null;
        }finally{
            ConexaoBanco.fecharConexao(con);
        }
        return cliente;
    }
    
    /*public boolean atualizar(Cliente cliente)throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        String sql = "update cliente set senha = ?, no_cliente = ?, telefone = ? where cpf = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cliente.getSenha());
            stmt.setString(2, cliente.getNome());
            stmt.setString(3, cliente.getTelefone());
            stmt.setString(4, cliente.getCpf());
            
            stmt.executeUpdate();
            
            con.commit();
           
            
            return true;
        }catch(SQLException ex){
            if(con !=null){
            try{
                con.rollback();
                System.err.println(ex);
                return false;
            }catch(SQLException ex1){
                System.err.println(ex1);
            }
        }
             return false;
        }finally{
    ConexaoBanco.fecharConexao(con);
    }
   }*/
    public boolean atualizar(Cliente cliente) throws SQLException {
    con = (Connection) ConexaoBanco.conectar();
    String sql;
    PreparedStatement stmt;

    if (cliente.getSenha() != null && !cliente.getSenha().trim().isEmpty()) {
        // Atualiza tudo, inclusive a senha
        sql = "UPDATE cliente SET senha = ?, no_cliente = ?, telefone = ? WHERE cpf = ?";
        stmt = con.prepareStatement(sql);
        stmt.setString(1, cliente.getSenha());
        stmt.setString(2, cliente.getNome());
        stmt.setString(3, cliente.getTelefone());
        stmt.setString(4, cliente.getCpf());
    } else {
        // Atualiza sem alterar a senha
        sql = "UPDATE cliente SET no_cliente = ?, telefone = ? WHERE cpf = ?";
        stmt = con.prepareStatement(sql);
        stmt.setString(1, cliente.getNome());
        stmt.setString(2, cliente.getTelefone());
        stmt.setString(3, cliente.getCpf());
    }

    try {
        con.setAutoCommit(false);
        int linhasAfetadas = stmt.executeUpdate();
        con.commit();
        return linhasAfetadas > 0;
    } catch (SQLException ex) {
        if (con != null) {
            try {
                con.rollback();
                System.err.println("Erro ao atualizar cliente: " + ex);
                return false;
            } catch (SQLException ex1) {
                System.err.println("Erro no rollback: " + ex1);
            }
        }
        return false;
    } finally {
        ConexaoBanco.fecharConexao(con);
    }
}

    
    public boolean excluir (int id)throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        String sql = "delete from cliente where id_cliente = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            
            stmt.setInt(1, id);
            
            int linhasAfetadas = stmt.executeUpdate();
            con.commit();
          
            
            return linhasAfetadas>0;
            
        }catch(SQLException ex){
            if (con != null) {
            try {
                con.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erro no rollback: " + rollbackEx);
            }
        }
        System.err.println("Erro ao excluir cliente: " + ex);
        return false;
    } finally  {
            ConexaoBanco.fecharConexao(con);
            
        }
    }
    
    public int login(String cpf, String senha) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        int ret=0;
        
        String sql = "Select count(*) as total from cliente where cpf = ? and senha = md5(?)";
        
        try{
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, cpf);
            pstmt.setString(2, senha);
            
            
            ResultSet rs = pstmt.executeQuery();
            
            if(rs.next()){
                ret = rs.getInt("total");
            }
            
            rs.close();
            pstmt.close();
        }catch(SQLException ex){
            System.err.println("Erro no login: " + ex.getMessage());
            return ret;
        }finally{
        ConexaoBanco.fecharConexao(con);
    }
        return ret;
    }
    
    public Cliente procurar(int id) throws SQLException {
        Cliente cliente = null;
        con = (Connection) ConexaoBanco.conectar();

        String sql = "SELECT * FROM cliente WHERE id_cliente = ?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cliente = new Cliente();
                    cliente.setId(rs.getInt("id_cliente"));
                    cliente.setNome(rs.getString("no_cliente"));
                    cliente.setCpf(rs.getString("cpf"));
                    cliente.setTelefone(rs.getString("telefone"));
                    cliente.setData_nascimento(rs.getDate("data_nasc"));
                }
            }
        } catch (SQLException ex) {
            System.err.println("Erro ao procurar cliente: " + ex.getMessage());
            throw ex;
        } finally {
            ConexaoBanco.fecharConexao(con);
        }

        return cliente;
    }
    public boolean autenticar(String cpf, String senha) throws SQLException {
    // l�gica de autentica��o (retorna, por exemplo, 1 se v�lido, 0 se inv�lido)
     Connection conn = ConexaoBanco.conectar(); // adapte para seu m�todo de conex�o

    String sql = "SELECT * FROM cliente WHERE cpf = ? AND senha = md5(?)";
    PreparedStatement stmt = conn.prepareStatement(sql);
    stmt.setString(1, cpf);
    stmt.setString(2, senha);
    ResultSet rs = stmt.executeQuery();

    if (rs.next()) {
        // Encontrou um funcion�rio com CPF e senha v�lidos
        return true;  // ou qualquer valor que signifique sucesso
    }
    return false;  // significa que n�o autenti
}
 }

