/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package ete.piviews;

import ete.negocios.Cliente;
import ete.negocios.Funcionario;
import ete.pirepositorio.RepFuncionario;
import ete.pirepositorio.UsuarioLogado;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;
import ete.piviews.TelaLogin;

/**
 *
 * @author Jose Fabricio Silva
 */
public class editarFuncionario extends javax.swing.JDialog {

    /**
     * Creates new form editarFuncionario
     */
    public editarFuncionario(){
        
    }
    public editarFuncionario(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        criarTabela();
        carregarFuncionarios();
        
        txtNome = new javax.swing.JTextField();
        txtCargo = new javax.swing.JTextField();
        txtSenha = new javax.swing.JPasswordField();
        btnSalvar = new javax.swing.JButton("Salvar");
        
        javax.swing.JLabel lblNome = new javax.swing.JLabel("Nome: ");
        javax.swing.JLabel lblCargo = new javax.swing.JLabel("Cargo: ");
        javax.swing.JLabel lblSenha = new javax.swing.JLabel("Senha");
        
        lblNome.setBounds(540, 30, 200, 20);
        txtNome.setBounds(540, 50, 200, 25);
        
        lblCargo.setBounds(540, 90, 200, 20);
        txtCargo.setBounds(540, 110, 200, 25);
        
        lblSenha.setBounds(540, 150, 200, 20);
        txtSenha.setBounds(540, 170, 200, 25);
        
        btnSalvar.setBounds(540, 220, 200, 35);
        
        jPanel1.add(lblNome);
        jPanel1.add(txtNome);
        jPanel1.add(lblCargo);
        jPanel1.add(txtCargo);
        jPanel1.add(lblSenha);
        jPanel1.add(txtSenha);
        jPanel1.add(btnSalvar);
        
        tabelaFuncionarios.getSelectionModel().addListSelectionListener(event ->{
            if(!event.getValueIsAdjusting() && tabelaFuncionarios.getSelectedRow() != -1){
                int linha = tabelaFuncionarios.getSelectedRow();
                int idFuncionario = (int) modelo.getValueAt(linha, 0);
                
                try{
                    FuncionarioSelecionado = RepFuncionario.procurarId(idFuncionario);
                    if(FuncionarioSelecionado != null){
                        txtNome.setText(FuncionarioSelecionado.getNome());
                        txtCargo.setText(FuncionarioSelecionado.getCargo());
                        txtSenha.setText("");
                     


                        
                        if (UsuarioLogado.getFuncionario() != null && 
                                UsuarioLogado.getFuncionario().getCargo().equalsIgnoreCase("admin")){
                             // Admin pode editar tudo
                         btnSalvar.setEnabled(true);
                         txtNome.setEditable(true);
                         txtCargo.setEditable(true);
                         txtSenha.setEditable(true);
                        }else{
                            //bloquei pra quem n�o � adm
                            btnSalvar.setEnabled(false);
                            txtNome.setEditable(false);
                            txtCargo.setEditable(false);
                            txtSenha.setEditable(false);
                            JOptionPane.showMessageDialog(this, "Apenas administradores podem alterar funcion�rios.");
                        }
                    }
                    
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(this, "Erro ao carregar funcionario: "+ex.getMessage());
                }
            }
        });
        btnSalvar.addActionListener(e ->{
               if (UsuarioLogado.getFuncionario() == null || 
    !UsuarioLogado.getFuncionario().getCargo().equalsIgnoreCase("admin")) {
    JOptionPane.showMessageDialog(this, "Apenas administradores podem atualizar dados de funcion�rios.");
    return;
               }
            if(FuncionarioSelecionado == null){
                JOptionPane.showMessageDialog(this, "Selecione um funcion�rio para atualizar.");
                return;
            }
            String nome = txtNome.getText().trim();
            String cargo = txtCargo.getText().trim();
            String senha = new String(txtSenha.getPassword()).trim();//estudar trim
            
            if(nome.isEmpty()){
                JOptionPane.showMessageDialog(this, "Nome n�o pode ficar vazio.");
                return;
            }
            FuncionarioSelecionado.setNome(nome);
            FuncionarioSelecionado.setCargo(cargo);
            
           /* if(!senha.isEmpty()){
                FuncionarioSelecionado.setSenha(senha);//vai ser md5 no banco
            }else{
                //n�o altera se estiver vazio
                FuncionarioSelecionado.setSenha("");
            }*/
       if (senha != null && !senha.trim().isEmpty()) {
    String senhaHash = TelaLogin.gerarHashMD5(senha);
    FuncionarioSelecionado.setSenha(senhaHash);
} 
// sen�o, N�O mexe na senha!

            try{
                boolean atualizado = RepFuncionario.atualizar(FuncionarioSelecionado);
                if(atualizado){
                    JOptionPane.showMessageDialog(this, "Funcion�rio atualizado com sucesso!");
                    carregarFuncionarios();
                }else{
                    JOptionPane.showMessageDialog(this, "Falha ao atualizar funcion�rio.");
                }
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, "Erro: "+ex.getMessage());
            }
            /*if(UsuarioLogado.getFuncionario() != null){
                if(FuncionarioSelecionado.getId() != UsuarioLogado.getFuncionario().getId()){
                    JOptionPane.showMessageDialog(this, "Voc� n�o pode editar outras contas.");
                }
            }*/
        });
        
        //Buscar funcion�rio
        javax.swing.JLabel lblBuscarCpf = new javax.swing.JLabel("Buscar CPF:");
        javax.swing.JTextField txtBuscarCpf = new javax.swing.JTextField();
        javax.swing.JButton btnBuscarCpf = new javax.swing.JButton("Buscar");
        
        lblBuscarCpf.setBounds(540, 270, 200, 20);
        txtBuscarCpf.setBounds(540, 290, 200, 25);
        btnBuscarCpf.setBounds(540, 320, 200, 30);
        
        jPanel1.add(lblBuscarCpf);
        jPanel1.add(txtBuscarCpf);
        jPanel1.add(btnBuscarCpf);
        
        JButton btnDesativar = new JButton("Desativar conta");
        btnDesativar.setBounds(540, 370, 200, 35);
        jPanel1.add(btnDesativar);
        
        JButton btnAtivar = new JButton("Ativar conta");
        btnAtivar.setBounds(540, 420, 200, 35);
        jPanel1.add(btnAtivar);
        
        btnBuscarCpf.addActionListener(e ->{
            String cpf = txtBuscarCpf.getText().trim();
            if(cpf.isEmpty()){
                JOptionPane.showMessageDialog(this, "Digite o CPF para buscar.");
                return;
            }
            try{
                Funcionario f = RepFuncionario.achar(cpf);
                if(f != null){
                    txtNome.setText(f.getNome());
                    txtCargo.setText(f.getCargo());
                    txtSenha.setText("");
                    FuncionarioSelecionado = f;
                    
                    //seleciona o mano  na tabela
                    for(int i = 0; i< modelo.getRowCount(); i++){
                        if((int) modelo.getValueAt(i, 0) == f.getId()){
                            tabelaFuncionarios.setRowSelectionInterval(i, i);
                            break;
                        }
                    }
                    if (UsuarioLogado.getFuncionario() != null && 
                UsuarioLogado.getFuncionario().getCargo().equalsIgnoreCase("admin")) {
                
                btnSalvar.setEnabled(true);
                btnDesativar.setEnabled(true);
                btnAtivar.setEnabled(true);

            } else if (UsuarioLogado.getFuncionario() != null &&
                       FuncionarioSelecionado.getId() == UsuarioLogado.getFuncionario().getId()) {

                btnSalvar.setEnabled(true);
                btnDesativar.setEnabled(true);
                btnAtivar.setEnabled(false);
            } else {
                btnSalvar.setEnabled(false);
                btnDesativar.setEnabled(false);
                btnAtivar.setEnabled(false);
            }

                }else{
                    JOptionPane.showMessageDialog(this, "Funcion�rio n�o encontrado.");
                }
            }catch(Exception ex){
                 JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
            }
        });
        
        
        btnDesativar.addActionListener(e ->{
            if (UsuarioLogado.getFuncionario() == null || 
    !UsuarioLogado.getFuncionario().getCargo().equalsIgnoreCase("admin")) {
    JOptionPane.showMessageDialog(this, "Apenas administradores podem ativar/desativar contas.");
    return;
}

            if(FuncionarioSelecionado == null){
                JOptionPane.showMessageDialog(this, "Selecione um funcion�rio para desativar.");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja desativar a conta"
                    + " de cliente?", "Confirma��o", JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION){
                try{
                    boolean desativado = RepFuncionario.desativar(FuncionarioSelecionado.getId());
                    if(desativado){
                        JOptionPane.showMessageDialog(this, "Conta desativada com sucesso.");
                        FuncionarioSelecionado = null;
                        txtNome.setText("");
                        txtCargo.setText("");
                        txtSenha.setText("");
                        carregarFuncionarios();
                    }else{
                        JOptionPane.showMessageDialog(this, "Erro ao desativar conta.");
                        
                    }
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(this, "Erro: "+ex.getMessage());
                }
            }
        });
        btnAtivar.addActionListener(e ->{
            if (UsuarioLogado.getFuncionario() == null || 
    !UsuarioLogado.getFuncionario().getCargo().equalsIgnoreCase("admin")) {
    JOptionPane.showMessageDialog(this, "Apenas administradores podem ativar/desativar contas.");
    return;
}

            if(FuncionarioSelecionado == null){
                JOptionPane.showMessageDialog(this, "Selecione um cliente para ativar.");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this, "Deseja ativar essa conta?", "Confirma��o", JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION){
                try{
                    boolean ativado = RepFuncionario.ativar(FuncionarioSelecionado.getId());
                    if(ativado){
                        JOptionPane.showMessageDialog(this, "Conta ativada com sucesso.");
                        carregarFuncionarios();
                    }else{
                        JOptionPane.showMessageDialog(this, "Erro ao ativar conta.");
                    }
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(this, "Erro: "+ex.getMessage());
                }
            }
        });
    if(UsuarioLogado.getFuncionario() != null){
        String cargo = UsuarioLogado.getFuncionario().getCargo();
        if(cargo.equals("admin")){
            JOptionPane.showMessageDialog(this, "Apenas administradores podem alterar outros funcionarios");
            return;
        }
    }
    }
    private RepFuncionario RepFuncionario = new RepFuncionario(); 
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtCargo;
    private javax.swing.JPasswordField txtSenha;
    private javax.swing.JButton btnSalvar;
    
    private Funcionario FuncionarioSelecionado;
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 770, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 486, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(editarFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(editarFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(editarFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(editarFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                editarFuncionario dialog = new editarFuncionario(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    private JTable tabelaFuncionarios;
    private DefaultTableModel modelo;
    private void criarTabela(){
        modelo = new DefaultTableModel(
        new String[]{"ID", "Nome", "Data de Nascimento", "Cargo"}, 0){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tabelaFuncionarios = new JTable(modelo);
        
       JScrollPane scroll = new JScrollPane(tabelaFuncionarios);
        scroll.setBounds(0, 0, 500, 300);
        jPanel1.setLayout(null);
        jPanel1.add(scroll); //duvidas nesse scroll e na parte do layout 
    }
    public void carregarFuncionarios(){
        try{
            modelo.setRowCount(0);//olhar isso novamente
            
            List<Funcionario> lista = RepFuncionario.retornar();
            
            if(lista != null){
                for(Funcionario f : lista){
                    modelo.addRow(new Object[]{
                    f.getId(),
                    f.getNome(),
                    f.getData_nascimento(),
                    f.getCargo()
                });
            }
        }else{
                JOptionPane.showMessageDialog(this, "Erro ao carregar funcion�rios");
            }
    }catch(Exception ex){
        JOptionPane.showMessageDialog(this, "Erro: " +ex.getMessage());
        ex.printStackTrace();
    }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
