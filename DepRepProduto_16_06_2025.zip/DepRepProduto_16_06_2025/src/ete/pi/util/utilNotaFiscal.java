/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ete.pi.util;
import ete.negocios.Venda;
import ete.negocios.ItemVenda;
import java.text.SimpleDateFormat;
/**
 *
 * @author Jose Fabricio Silva
 */
public class utilNotaFiscal {
    
    public utilNotaFiscal(){
        
    }
    public static String gerarNotaFiscal(Venda venda) {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        sb.append("*************** NOTA FISCAL ***************\n");
        sb.append("Data: ").append(sdf.format(venda.getData_venda())).append("\n");
        sb.append("Cliente: ").append(venda.getCliente().getNome()).append("\n");
        sb.append("Funcion�rio: ");
if (venda.getFuncionario() != null) {
    sb.append(venda.getFuncionario().getNome()).append("\n");
} else {
    sb.append("N�o identificado\n");
}
        sb.append("------------------------------------------\n");
        sb.append(String.format("%-5s %-20s %-7s %-10s %-10s\n", "ID", "Produto", "Qtd", "Pre�o", "Subtotal"));
        sb.append("------------------------------------------\n");
        
        double total = 0.0;
        for(ItemVenda item : venda.getItens()){
            int qtd = item.getQuantidade();
            double preco = item.getPreco_unid();
            double subtotal = qtd * preco;
            total += subtotal;
            
            sb.append(String.format("%-5d %-20s %-7d R$%-9.2f R$%-9.2f\n",
                    item.getProduto().getId(),
                    item.getProduto().getNome(),
                    qtd,
                    preco,
                    subtotal));
        }
        sb.append("------------------------------------------\n");
        sb.append(String.format("TOTAL: R$ %.2f\n", total));
        sb.append("******************************************\n");
        sb.append("Obrigado pela prefer�ncia!\n");

        return sb.toString();
        

    }
}
