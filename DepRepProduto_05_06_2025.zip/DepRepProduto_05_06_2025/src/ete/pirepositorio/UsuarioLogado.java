
package ete.pirepositorio;

import ete.negocios.Funcionario;
import ete.negocios.Cliente;

public class UsuarioLogado {
    private static String tipoUsuario;
    private static Funcionario funcionario;
    private static Cliente cliente;
   

    public static void setTipoUsuario(String tipo) {
        tipoUsuario = tipo;
    }

    public static String getTipoUsuario() {
        return tipoUsuario;
    }
}

