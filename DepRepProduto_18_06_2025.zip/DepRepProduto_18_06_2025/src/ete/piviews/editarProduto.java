/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package ete.piviews;

import ete.negocios.Produto;
import ete.pirepositorio.RepProduto;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.TextArea;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jose Fabricio Silva
 */
public class editarProduto extends javax.swing.JDialog {
    public editarProduto(){
        
    }
    
    private CardLayout cardLayout;
    private JPanel painelTabela , painelFormulario;
    
    private JTable tabelaProdutos;
    private DefaultTableModel modeloTabela;
    
    private JButton btnEditarSelecionado, btnAdicionarNovo, btnSalvar, btnCancelar, btnExcluirProduto;
    
    private JTextField campoNome, campoPreco, campoQuantidade, campoCategoria;
    private JTextArea campoDescricao;
    
    private boolean modoEdicao = false;
    private int idProdutoEditado = -1;
    
    public editarProduto(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        
        configurarComponentes();
        carregarProdutosNaTabela();
        
        cardLayout.show(jPanel1, "tabela");
    }
    private void limparCampos() {
    campoNome.setText("");
    campoPreco.setText("");
    campoQuantidade.setText("");
    campoDescricao.setText("");
    // campoCategoria.setText(""); // descomente se estiver usando campoCategoria
}

    private void configurarComponentes(){//estudar isso
        //definir layout card
        cardLayout = new CardLayout();
        jPanel1.setLayout(cardLayout);
        
        //painel tabela
        painelTabela = new JPanel(new BorderLayout());
        
        modeloTabela = new DefaultTableModel(
        new String[]{"ID", "Nome", "Pre�o", "Quantidade", "Descr��o"},0){
            @Override
            public boolean isCellEditable(int row, int col){return false;}
        };
        tabelaProdutos = new JTable(modeloTabela);
        tabelaProdutos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        painelTabela.add(new JScrollPane(tabelaProdutos), BorderLayout.CENTER);
        
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15,10));
        btnEditarSelecionado = new JButton("Editar Produto selecionado");
        btnAdicionarNovo = new JButton("Adicionar Novo Produto");
        btnExcluirProduto = new JButton("Excluir Produto");
        painelBotoes.add(btnEditarSelecionado);
        painelBotoes.add(btnAdicionarNovo);
        painelBotoes.add(btnExcluirProduto);
        
        painelTabela.add(painelBotoes, BorderLayout.SOUTH);
        
        //painel frormul�rio
        painelFormulario = new JPanel();
        painelFormulario.setLayout(new BoxLayout(painelFormulario, BoxLayout.Y_AXIS));
        painelFormulario.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        painelFormulario.setPreferredSize(new Dimension(750,450));
        
        painelFormulario.add(criarPainelCampo("Nome:", campoNome = new JTextField(30)));
        painelFormulario.add(criarPainelCampo("Pre�o:", campoPreco = new JTextField(15)));
        painelFormulario.add(criarPainelCampo("Quantidade", campoQuantidade = new JTextField(15)));
     
         JPanel painelDescricao = new JPanel(new BorderLayout());
         painelDescricao.setBorder(BorderFactory.createTitledBorder("Descri��o:"));
         campoDescricao = new JTextArea(5, 30);
         campoDescricao.setLineWrap(true);
         campoDescricao.setWrapStyleWord(true);
         JScrollPane scrollDescricao = new JScrollPane(campoDescricao);
         scrollDescricao.setPreferredSize(new Dimension(700, 90));
         painelDescricao.add(scrollDescricao, BorderLayout.CENTER);
         painelFormulario.add(painelDescricao);


        
        JPanel painelBotoesForm = new JPanel(new FlowLayout(FlowLayout.CENTER,20,10));
        btnSalvar = new JButton("Salvar");
        btnCancelar = new JButton("Cancelar");
        painelBotoesForm.add(btnSalvar);
        painelBotoesForm.add(btnCancelar);
        painelFormulario.add(painelBotoesForm);

        
        jPanel1.add(painelTabela, "tabela");
    jPanel1.add(painelFormulario, "formulario");
    
    // A��es dos bot�es
        btnExcluirProduto.addActionListener(e -> {
            try {
                excluirProdutoSelecionado();
            } catch (SQLException ex) {
                Logger.getLogger(editarProduto.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btnEditarSelecionado.addActionListener(e -> editarProdutoSelecionado());
        btnAdicionarNovo.addActionListener(e -> adicioanrNovoProduto());
        btnSalvar.addActionListener(e -> {
            try {
                salvarProduto();
            } catch (SQLException ex) {
                Logger.getLogger(editarProduto.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btnCancelar.addActionListener(e -> cancelarEdicao());


    }
    

    private JPanel criarPainelCampo(String texto, JTextField campo){
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel label = new JLabel(texto);
        label.setPreferredSize(new Dimension(100, 25));
        campo.setPreferredSize(new Dimension(250, 25));
        p.add(label);
        p.add(campo);
        return p;
    }
    
    private void excluirProdutoSelecionado() throws SQLException{
        int linha = tabelaProdutos.getSelectedRow();
        if (linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um produto para excluir.");
            return;
        }
        int confirmacao = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja excluir este produto?", "Confirma��o", JOptionPane.YES_NO_OPTION);
        
        if(confirmacao == JOptionPane.YES_OPTION){
            int idProduto = (int) modeloTabela.getValueAt(linha, 0);
            RepProduto rep = new RepProduto();
            boolean sucesso = rep.excluir(idProduto);
            
            if(sucesso){
                JOptionPane.showMessageDialog(this, "Produto exclu�do com sucesso.");
                carregarProdutosNaTabela();
            }else{
                JOptionPane.showMessageDialog(this, "Erro ao excluir produto");
            }
        }
    }
    private void carregarProdutosNaTabela(){
        modeloTabela.setRowCount(0);
        RepProduto repProduto = new RepProduto();
        List<Produto> lista = null;
        try{
            lista = repProduto.retornar();
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(this, "Erro ao carregar Produtos: "+ex.getMessage());
            return;
        }
        if(lista != null){
            for (Produto p : lista){
                modeloTabela.addRow(new Object[]{
                    p.getId(),
                    p.getNome(),
                    p.getPreco(),
                    p.getQuantidade(),
                    p.getDescricao()
                });
           }
        }
    }
    private void editarProdutoSelecionado(){
        int linha = tabelaProdutos.getSelectedRow();
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um produto para editar.");
            return;
        }
        idProdutoEditado = (int) modeloTabela.getValueAt(linha, 0);
        campoNome.setText((String) modeloTabela.getValueAt(linha, 1));
        campoPreco.setText(modeloTabela.getValueAt(linha, 2).toString());
        campoQuantidade.setText(modeloTabela.getValueAt(linha, 3).toString());
        campoDescricao.setText((String)modeloTabela.getValueAt(linha, 4));
        
        modoEdicao = true;
        cardLayout.show(jPanel1, "formulario");
    }
    private void adicioanrNovoProduto(){
        limparCampos();
        modoEdicao = false;
        idProdutoEditado = -1;
        cardLayout.show(jPanel1, "formulario");
    }
    private void cancelarEdicao(){
        limparCampos();
        cardLayout.show(jPanel1, "tabela");
        
    }
    private void salvarProduto() throws SQLException{
        String nome = campoNome.getText().trim();
        String precoStr = campoPreco.getText().trim();
        String quantidadeStr = campoQuantidade.getText().trim();
        String descricao = campoDescricao.getText().trim();
        
        if (nome.isEmpty() || precoStr.isEmpty() || quantidadeStr.isEmpty()){
            JOptionPane.showMessageDialog(this, "Preencha todos os campos obrigat�rios.");
            return;
        }
        
        double preco;
        int quantidade;
        
        try{
            preco = Double.parseDouble(precoStr);//o double maiusculo???
            quantidade = Integer.parseInt(quantidadeStr);
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(this, "Pre�o ou quantidade inv�lidos.");
            return;
        }
       if(preco < 0 || quantidade < 0){
           JOptionPane.showMessageDialog(this, "Pre�o e quantidade n�o podem ser negativos.");
           return;
       }
       Produto p = new Produto(idProdutoEditado, nome, descricao, quantidade, preco);
       boolean sucesso;
       if(modoEdicao){
           RepProduto repo = new RepProduto();
           sucesso = repo.atualizar(p);
           if(sucesso){
               JOptionPane.showMessageDialog(this, "Produto atualizado com sucesso.");
               
           }else{
               JOptionPane.showMessageDialog(this, "Erroa ao atualizar produto.");
           }
       }else{
           RepProduto rep = new RepProduto();
           sucesso = rep.inserir(p);
           if(sucesso){
               JOptionPane.showMessageDialog(this, "Produto inserido com sucesso.");
           }else{
               JOptionPane.showMessageDialog(this, "Erro ao inserir produto.");
           }
       }
       carregarProdutosNaTabela();
       cardLayout.show(jPanel1, "tabela");
       limparCampos();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 770, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 486, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(editarProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(editarProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(editarProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(editarProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                editarProduto dialog = new editarProduto(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
