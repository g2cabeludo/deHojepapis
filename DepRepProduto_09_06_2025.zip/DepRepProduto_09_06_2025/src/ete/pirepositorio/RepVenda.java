
package ete.pirepositorio;

import ete.banco.ConexaoBanco;
import ete.negocios.ItemVenda;
import ete.negocios.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import ete.negocios.Venda;
import ete.pirepositorio.RepCliente;
import ete.pirepositorio.RepFuncionario;
import ete.pirepositorio.RepProduto;

public class RepVenda {
    
  
    private RepCliente repcliente;
    
    private RepProduto repProduto;
    Connection con;
    
    public RepVenda(Connection con, RepCliente repcliente, RepProduto repProduto) throws SQLException{
        this.con = ConexaoBanco.conectar(); // ou o m�todo correto da sua classe de conex�o
        this.repcliente = repcliente;
        
        this.repProduto = repProduto;
        
}
    public RepVenda(){
        
    }
    
    public boolean inserir (Venda venda) throws SQLException{
        
        
       
         boolean originalAutoCommit = con.getAutoCommit();
         con.setAutoCommit(false);
         
        String sql = "insert into venda (cliente_id, data_venda, valor_total) VALUES (?, ?,  ?)";
        
        try (PreparedStatement stmtVenda = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)){
            stmtVenda.setInt(1, venda.getCliente().getId());
           
            stmtVenda.setDate(2, new java.sql.Date(venda.getData_venda().getTime()));
            stmtVenda.setDouble(3, venda.getValor_total());
            
            stmtVenda.executeUpdate();
           
            try (ResultSet rs = stmtVenda.getGeneratedKeys()) {
                if (rs.next()) {
                    int idVenda = rs.getInt(1);
                    
                    String sqlItem = "INSERT INTO item_venda (venda_id, produto_id, quantidade, preco_unidade) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement stmtItem = con.prepareStatement(sqlItem)) {
                        for (ItemVenda item : venda.getItens()) {
                            stmtItem.setInt(1, idVenda);
                            stmtItem.setInt(2, item.getProduto().getId());
                            stmtItem.setInt(3, item.getQuantidade());
                            stmtItem.setDouble(4, item.getPreco_unid());
                            stmtItem.addBatch();
                        }
                        stmtItem.executeBatch(); 
                    }
                    con.commit(); // Finaliza transa��o
                return true;
                } else{
                    throw new SQLException("Falha ao obter o ID gerado para a venda ap�s inser��o.");
                }
            }
        }catch(SQLException ex){
            if(con!=null){
                try{
                    con.rollback();
                } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
        }
          throw new SQLException("Erro ao inserir venda e itens: " + ex.getMessage(), ex);
    } finally {
        try {
            con.setAutoCommit(originalAutoCommit); // Restaura o autoCommit original
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        }
       
    }
      public Venda procurar(int idVenda) throws SQLException{
         Venda venda = null;
         
         String sqlVenda = "select cliente_id,  data_venda, valor_total "
                 + " from venda where id = ?";
        try(PreparedStatement stmtVenda = con.prepareStatement(sqlVenda)){
            stmtVenda.setInt(1, idVenda);
            
            try(ResultSet rs = stmtVenda.executeQuery()){
                if(rs.next()){
                    venda = new Venda();
                    venda.setId(idVenda);
                    
                    venda.setCliente(repcliente.procurar(rs.getInt("cliente_id")));
                    
                    
                    venda.setData_venda(rs.getDate("data_venda"));
                    venda.setValor_total(rs.getDouble("valor_total"));
                    
                    String sqlItens = "select produto_id, quantidade, preco_unidade from item_venda where "
                            + "venda_id = ?";
                    try(PreparedStatement stmtItens = con.prepareStatement(sqlItens)){
                        stmtItens.setInt(1, idVenda);
                        
                        try(ResultSet rsItens = stmtItens.executeQuery()){
                            List<ItemVenda> itens = new ArrayList<>();
                            
                            
                            while(rsItens.next()){
                                ItemVenda item = new ItemVenda();
                                

                                int idProduto = rsItens.getInt("produto_id");
                                
                                
                                Produto produto = this.repProduto.procurar(idProduto);
                                item.setProduto(produto);
                                
                                item.setQuantidade(rsItens.getInt("quantidade"));
                                item.setPreco_unid(rsItens.getDouble("preco_unidade"));
                                itens.add(item);
                                
                            }
                            venda.setItens(itens);
                        }
                    }
                }
            }
}
        return venda;
}

      
}   
  
