package ete.negocios;


import java.util.Date;


public class Funcion�rio extends Pessoa{
    private String cargo;
    private String senha;
    
    public Funcion�rio(int id, String nome, String cpf, Date data, String cargo){
            super(nome, cpf, data, id);
            this.cargo = cargo;
         
    } 

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
}
