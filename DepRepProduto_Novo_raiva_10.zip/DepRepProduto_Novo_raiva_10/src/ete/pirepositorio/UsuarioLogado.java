
package ete.pirepositorio;

public class UsuarioLogado {
    private static String tipoUsuario;

    public static void setTipoUsuario(String tipo) {
        tipoUsuario = tipo;
    }

    public static String getTipoUsuario() {
        return tipoUsuario;
    }
}

