
package ete.pirepositorio;

import ete.banco.ConexaoBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import ete.negocios.Venda;

public class RepVenda {
    Connection con;
    
    public boolean inserir (Venda venda) throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        
        String sql = "insert into venda (cliente_id, funcionario_id,"
                + " data_venda, valor_total) VALUES (?, ?, ?, ?)";
        
        

    }
    
}
