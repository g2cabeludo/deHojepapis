/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package ete.piviews;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import ete.negocios.Cliente;
import ete.negocios.Funcionario;
import ete.negocios.ItemVenda;
import ete.negocios.Produto;
import ete.negocios.Venda;
import ete.pirepositorio.RepCliente;
import ete.pirepositorio.RepFuncionario;
import ete.pirepositorio.RepProduto;
import ete.pirepositorio.RepVenda;
import ete.pirepositorio.UsuarioLogado;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.print.PrinterException;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;

/**
 *
 * @author Jose Fabricio Silva
 */
public class InsetVendaFunc extends javax.swing.JDialog {

    /**
     * Creates new form InsetVendaFunc
     */
    public InsetVendaFunc(){
        
    }
    private JTextField txtCpfCliente;
    private JButton btnBuscarCliente, btnAdicionarCarrinho, btnFinalizarCompra, btnVoltar;
    private JLabel lblClienteInfo, lblTotal;
    private JTable tabelaProdutos, tabelaCarrinho;
    private JTextArea txtDescricao;
    private JSpinner spinnerQtd;
    private DefaultTableModel modeloProdutos, modeloCarrinho;
     private List<Produto> listaProdutos;
    private List<ItemVenda> carrinho = new ArrayList<>();
    private Cliente clienteSelecionado;
    
    private RepCliente repCliente = new RepCliente();
    private RepVenda repVenda = new RepVenda();
    private RepProduto repProduto = new RepProduto();
    
    
    public InsetVendaFunc(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        setTitle("Nova Compra - Funcion�rio");
        initComponents();
        setLocationRelativeTo(null);
       jPanel1.setLayout(new BorderLayout());
        
        
        getContentPane().add(jPanel1);
        
        //painel direito
        JPanel painelBotoes = new JPanel();
        painelBotoes.setLayout(new BoxLayout(painelBotoes, BoxLayout.Y_AXIS));
        painelBotoes.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        
        JLabel lblCpf = new JLabel("CPF Cliente:");
        txtCpfCliente = new JTextField(11);
        txtCpfCliente.setMaximumSize(new Dimension(170, 25));
        txtCpfCliente.setPreferredSize(new Dimension(170, 25));
        btnBuscarCliente = new JButton("Buscar Cliente");
        lblClienteInfo = new JLabel("Nenhum cliente selecionado");
        lblClienteInfo.setForeground(Color.BLUE);
        lblClienteInfo.setPreferredSize(new Dimension(150, 20));
        
        btnFinalizarCompra = new JButton("Finalizar Compra");
        btnVoltar = new JButton("Voltar");
        
        painelBotoes.add(lblCpf);
        painelBotoes.add(Box.createVerticalStrut(5));
        painelBotoes.add(txtCpfCliente);
        painelBotoes.add(Box.createVerticalStrut(5));
        painelBotoes.add(btnBuscarCliente);
        painelBotoes.add(Box.createVerticalStrut(15));
        painelBotoes.add(lblClienteInfo);
        painelBotoes.add(Box.createVerticalGlue());//estudar esses boxs
        painelBotoes.add(btnFinalizarCompra);
        
        jPanel1.add(painelBotoes, BorderLayout.EAST);
        
        //painel central
        JPanel jPanelTabela = new JPanel(new BorderLayout());
        jPanelTabela.setPreferredSize(new Dimension(550, 450));
        jPanel1.add(jPanelTabela, BorderLayout.CENTER);
        
        //tabela de produtos
        modeloProdutos = new DefaultTableModel(new String[]{"ID", "Nome", "Pre�o", "Quantidade"}, 0){
            @Override
            public boolean isCellEditable (int row, int column) {return false;}
        };
        tabelaProdutos = new JTable(modeloProdutos);
        JScrollPane scrollProdutos = new JScrollPane(tabelaProdutos);
        scrollProdutos.setPreferredSize(new Dimension(550,120));
        jPanelTabela.add(scrollProdutos, BorderLayout.NORTH);
        
        //Descri��o e algumas a��es
        txtDescricao = new JTextArea(3,40);
        txtDescricao.setEditable(false);
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDescricao);
        
        spinnerQtd = new JSpinner(new SpinnerNumberModel(1,1,100,1));
        btnAdicionarCarrinho = new JButton("Adicionar ao Carrinho");
        
        JPanel painelInfo = new JPanel(new BorderLayout());
        painelInfo.setBorder(BorderFactory.createTitledBorder("Informa��es do Produto"));
        painelInfo.add(scrollDesc, BorderLayout.CENTER);
        
        JPanel painelAcoes = new JPanel();
        painelAcoes.add(new JLabel("Quantidade"));
        painelAcoes.add(spinnerQtd);
        painelAcoes.add(btnAdicionarCarrinho);
        
        painelInfo.add(painelAcoes, BorderLayout.SOUTH);
        jPanelTabela.add(painelInfo, BorderLayout.CENTER);
        
                // Carrinho e total
        modeloCarrinho = new DefaultTableModel(new String[]{"ID", "Produto", "Qtd", "Pre�o", "Subtotal"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { 
                return false; 
            }
        };
        
        tabelaCarrinho = new JTable(modeloCarrinho);
        JScrollPane scrollCarrinho = new JScrollPane(tabelaCarrinho);
        scrollCarrinho.setPreferredSize(new Dimension(550,150));
        
        lblTotal = new JLabel("Total: R$ 0.00");
        JPanel painelCarrinho = new JPanel(new BorderLayout());
        painelCarrinho.setBorder(BorderFactory.createTitledBorder("Carrinho"));
        painelCarrinho.add(scrollCarrinho, BorderLayout.CENTER);
        painelCarrinho.add(lblTotal, BorderLayout.SOUTH);
        
        jPanelTabela.add(painelCarrinho, BorderLayout.SOUTH);
        
        
        btnBuscarCliente.addActionListener(e -> {
            try {
                buscarCliente();
            } catch (SQLException ex) {
                Logger.getLogger(InsetVendaFunc.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btnAdicionarCarrinho.addActionListener(e -> adicionarAoCarrinho());
        btnFinalizarCompra.addActionListener(e -> finalizarCompra());
        btnVoltar.addActionListener(e -> this.dispose());
        painelBotoes.add(btnVoltar);
        tabelaProdutos.getSelectionModel().addListSelectionListener(e ->{
            if(!e.getValueIsAdjusting() && tabelaProdutos.getSelectedRow() != -1 && listaProdutos != null){
                int index = tabelaProdutos.getSelectedRow();
                Produto selecionado = listaProdutos.get(index);
                txtDescricao.setText(selecionado.getDescricao());
            }
        });
        carregarProdutos();
        
    }
    private void carregarProdutos(){
        try{
            listaProdutos = repProduto.retornar();
            modeloProdutos.setRowCount(0);
            for(Produto p : listaProdutos){
                modeloProdutos.addRow(new Object[]{
                p.getId(), p.getNome(), p.getPreco(), p.getQuantidade()
            });
        }
    }catch(SQLException ex){
            JOptionPane.showMessageDialog(this, "Erro ao carregar produtos: "+ex.getMessage());
    }
    }
    private void buscarCliente() throws SQLException{
        String cpf = txtCpfCliente.getText().trim();
        if (cpf.isEmpty()){
            JOptionPane.showMessageDialog(this, "Digite o CPF do cliente.");
            return;
        }
        Cliente c = repCliente.achar(cpf);
        if(c != null){
            clienteSelecionado = c;
            lblClienteInfo.setText("Cliente: "+c.getNome());
        }else{
            clienteSelecionado = null;
            lblClienteInfo.setText("Cliente n� encontrado ou inativo");
            JOptionPane.showMessageDialog(this, "Cliente n� encontrado ou inativo");
        }
    
    }
    
    private void adicionarAoCarrinho() {
        int linha = tabelaProdutos.getSelectedRow();
        if (linha < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um produto para adicionar.");
            return;
        }
        Produto produto = listaProdutos.get(linha);

        int quantidade = (Integer) spinnerQtd.getValue();
        if (quantidade <= 0) {
            JOptionPane.showMessageDialog(this, "Quantidade inv�lida.");
            return;
        }
        if (produto.getQuantidade() < quantidade) {
            JOptionPane.showMessageDialog(this, "Estoque insuficiente para o produto: " + produto.getNome());
            return;
        }
         //Verifica se produto j� est� no carrinho para somar quantidade
        boolean achou = false;
        for (ItemVenda item : carrinho) {
            if (item.getProduto().getId() == produto.getId()) {
                item.setQuantidade(item.getQuantidade() + quantidade);
                achou = true;
                break;
            }
        }
        if (!achou) {
            carrinho.add(new ItemVenda(produto, quantidade));
        }
        atualizarCarrinho();
        JOptionPane.showMessageDialog(this, "Produto adicionado ao carrinho.");
    }
    private String gerarTextoNota(Venda venda){
        StringBuilder nota = new StringBuilder();
        
        nota.append("======== NOTA FISCAL PRESENCIAL ========\n");
        nota.append("Cliente: ").append(venda.getCliente().getNome()).append("\n");
        nota.append("Funcion�rio: ").append(venda.getFuncionario().getNome()).append("\n");
        nota.append("Data: ").append(new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm").format(venda.getData_venda())).append("\n");
        nota.append("========================================\n");
        nota.append(String.format("%-20s %-10s %-10s\n", "Produto", "Qtd", "Subtotal"));
        
        for (ItemVenda item : venda.getItens()){
            String nomeProd = item.getProduto().getNome();
            int quantidade = item.getQuantidade();
            double totalItem = item.getQuantidade() * item.getPreco_unid();
            
            nota.append(String.format("%-20s %-10d R$ %.2f\n", nomeProd, quantidade, totalItem));
            nota.append("========================================\n");
            nota.append(String.format("TOTAL FINAL: R$ %.2f\n", venda.getValor_total()));
            nota.append("========================================\n");
            
        }
        return nota.toString();
    }
    private void imprimirNotaFiscal(String textoNota){
        JTextArea area = new JTextArea(textoNota);
        try{
            boolean completo = area.print();//manda direto para a impressora padr�o
            if(!completo){
                JOptionPane.showMessageDialog(this, "Impress�o cancelada ou falhou.");
            }
        }catch(PrinterException e){
            JOptionPane.showMessageDialog(this, "Erro na impress�o: "+e.getMessage());
        }
    }
    
    private void atualizarCarrinho() {
        modeloCarrinho.setRowCount(0);
        double total = 0;

        for (ItemVenda item : carrinho) {
            double subtotal = item.getQuantidade() * item.getPreco_unid();
            total += subtotal;
            modeloCarrinho.addRow(new Object[]{
                    item.getProduto().getId(),
                    item.getProduto().getNome(),
                    item.getQuantidade(),
                    item.getPreco_unid(),
                    subtotal
            });
        }
        lblTotal.setText(String.format("Total: R$ %.2f", total));
    }
    private void finalizarCompra(){
        if(clienteSelecionado == null){
            JOptionPane.showMessageDialog(this, "Busque e selecione um cliente antes de finalizar a compra");
            return;
        }
        if (carrinho.isEmpty()){
            JOptionPane.showMessageDialog(this, "Carrinho vazio.");
            return;
        }
        
        Venda venda = new Venda();
        venda.setCliente(clienteSelecionado);
        venda.setFuncionario(UsuarioLogado.getFuncionario());
        venda.setData_venda(new Date());
        venda.setItens(new ArrayList<>(carrinho));
        
        double total = carrinho.stream()
                .mapToDouble(i -> i.getQuantidade() * i.getPreco_unid())
                .sum();
        venda.setValor_total(total);
        
         try {
            boolean sucesso = repVenda.inserir(venda);
            if (sucesso) {
                
                //gerar texto da nota fiscal
                String nota = gerarTextoNota(venda);
                
                //imprimir direto
                imprimirNotaFiscal(nota);
                
                JOptionPane.showMessageDialog(this, "Compra realizada com sucesso!");
                carrinho.clear();
                atualizarCarrinho();
                lblClienteInfo.setText("Nenhum cliente selecionado");
                clienteSelecionado = null;
                txtCpfCliente.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao finalizar a compra.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao finalizar a compra: " + ex.getMessage());
        }
    }

    

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 770, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 486, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InsetVendaFunc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InsetVendaFunc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InsetVendaFunc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InsetVendaFunc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                InsetVendaFunc dialog = new InsetVendaFunc(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
