
package ete.negocios;

public class ItemVenda {
    private int id;
    private Venda venda;
    private Produto produto;
    private int quantidade;
    private double preco_unid;
    
    public ItemVenda(int id, Produto produto, int quantidade, double preco_unid){
        this.id = id;
        this.venda = venda;
        this.produto = produto;
        this.quantidade = quantidade;
        this.preco_unid = preco_unid;
    }

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco_unid() {
        return preco_unid;
    }

    public void setPreco_unid(double preco_unid) {
        this.preco_unid = preco_unid;
    }
    
}
