
package ete.pirepositorio;

import ete.negocios.Funcionario;
import ete.negocios.Cliente;

public class UsuarioLogado {
    private static String tipoUsuario;
    private static Funcionario funcionario;
    private static Cliente cliente;
   

    public static void setTipoUsuario(String tipo) {
        tipoUsuario = tipo;
    }

    public static String getTipoUsuario() {
        return tipoUsuario;
    }
    
    public static void setFuncionario(Funcionario f) {
        funcionario = f;
    }

    public static Funcionario getFuncionario() {
        return funcionario;
    }

    public static void setCliente(Cliente c) {
        cliente = c;
    }

    public static Cliente getCliente() {
        return cliente;
    }
}

