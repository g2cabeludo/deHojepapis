/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package ete.piviews;
//imports
import ete.negocios.Cliente;
import ete.pirepositorio.RepCliente;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jose Fabricio Silva
 */
public class editarCliente extends javax.swing.JDialog {

    /**
     * Creates new form editarCliente
     */
    public editarCliente(){
        
    }
    public editarCliente(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        criarTabela();
        carregarClientes();
        setLocationRelativeTo(null);
        
        txtNome = new javax.swing.JTextField();
        txtTelefone = new javax.swing.JTextField();
        txtSenha = new javax.swing.JPasswordField();
        btnSalvar = new javax.swing.JButton("Salvar");
        
        javax.swing.JLabel lblNome = new javax.swing.JLabel("Nome: ");
        javax.swing.JLabel lblTelefone = new javax.swing.JLabel("Telefone: ");
        javax.swing.JLabel lblSenha = new javax.swing.JLabel("Senha: ");
        
        lblNome.setBounds(540, 30, 200, 20);
        txtNome.setBounds(540, 50, 200, 25);

        lblTelefone.setBounds(540, 90, 200, 20);
       txtTelefone.setBounds(540, 110, 200, 25);

       lblSenha.setBounds(540, 150, 200, 20);
       txtSenha.setBounds(540, 170, 200, 25);

       btnSalvar.setBounds(540, 220, 200, 35);
       
       jPanel1.add(lblNome);
       jPanel1.add(txtNome);
       jPanel1.add(lblTelefone);
       jPanel1.add(txtTelefone);
       jPanel1.add(lblSenha);
       jPanel1.add(txtSenha);
       jPanel1.add(btnSalvar);
       
       tabelaClientes.getSelectionModel().addListSelectionListener(event ->{//estudar  isso
           if(!event.getValueIsAdjusting() && tabelaClientes.getSelectedRow() != -1){
               int linha = tabelaClientes.getSelectedRow();
               int idCliente = (int) modelo.getValueAt(linha, 0);
               
               try{
                   clienteSelecionado = RepCliente.procurarId(idCliente);
                   
                   if(clienteSelecionado != null){
                       txtNome.setText(clienteSelecionado.getNome());
                       txtTelefone.setText(clienteSelecionado.getTelefone());
                       txtSenha.setText("");
                   }
               }catch(Exception ex){
                   JOptionPane.showMessageDialog(this, "Erro ao carregar cliente: "+ex.getMessage());
               }
           }
       });
       
       btnSalvar.addActionListener(e -> {
           if(clienteSelecionado == null){
               JOptionPane.showMessageDialog(this, "Selecione um cliente para atualizar.");
               return;
           }
           String nome = txtNome.getText().trim();
           String telefone = txtTelefone.getText().trim();
           String senha = new String(txtSenha.getPassword()).trim();//estudar esse trim
           
           if(nome.isEmpty()){
               JOptionPane.showMessageDialog(this, "Nome n�o pode ficar vazio.");
               return;
           }
           clienteSelecionado.setNome(nome);
           clienteSelecionado.setTelefone(telefone);
           
           if (!senha.isEmpty()) {
    clienteSelecionado.setSenha(senha); // A senha em texto puro vai ser md5 no SQL
} else {
    // N�o alterar a senha se o campo estiver vazio
    clienteSelecionado.setSenha(""); // OU: n�o seta nada e trata isso no update
}
           try{
               boolean atualizado = RepCliente.atualizar(clienteSelecionado);
               if(atualizado){
                   JOptionPane.showMessageDialog(this, "Cliente atualizado com sucesso!");
                   carregarClientes();
                   
               }else{
                   JOptionPane.showMessageDialog(this, "Falha ao atualizar cliente.");
               }
           }catch(Exception ex){
               JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
           }
       });//senha esta errada com hash
       
       
        //Buscar cliente
    javax.swing.JLabel lblBuscarCpf = new javax.swing.JLabel("Buscar CPF:");
    javax.swing.JTextField txtBuscarCpf = new javax.swing.JTextField();
    javax.swing.JButton btnBuscarCpf = new javax.swing.JButton("Buscar");

    lblBuscarCpf.setBounds(540, 270, 200, 20);
    txtBuscarCpf.setBounds(540, 290, 200, 25);
    btnBuscarCpf.setBounds(540, 320, 200, 30);
    
    jPanel1.add(lblBuscarCpf);
    jPanel1.add(txtBuscarCpf);
    jPanel1.add(btnBuscarCpf);
    
    btnBuscarCpf.addActionListener(e -> {
        String cpf = txtBuscarCpf.getText().trim();//pesquisar esse trim
        if(cpf.isEmpty()){//pesquisar esse empty
            JOptionPane.showMessageDialog(this, "Digite o CPF para buscar.");
            return;
        }
        try{
            Cliente c = RepCliente.achar(cpf);
            if(c != null){
                txtNome.setText(c.getNome());
                txtTelefone.setText(c.getTelefone());
                txtSenha.setText("");
                clienteSelecionado = c;
                
                //seleciona na tabela
                for(int i = 0; i < modelo.getRowCount(); i++){
                    if((int) modelo.getValueAt(i, 0) == c.getId()){
                        tabelaClientes.setRowSelectionInterval(i, i);
                        break;
                    }//pesquisar esse for
                }
            }else{
                JOptionPane.showMessageDialog(this, "Cliente n�o encontrado.");
            }
        }catch (Exception ex){
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
        }
    });
    javax.swing.JButton btnExcluir = new javax.swing.JButton("Excluir Cliente");
    btnExcluir.setBounds(540, 370, 200, 35);
    jPanel1.add(btnExcluir);
    
    btnExcluir.addActionListener(e -> {
        if (clienteSelecionado == null){
            JOptionPane.showMessageDialog(this, "Selecione um cliente para excluir.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja excluir o cliente", "Confirma��o", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION){
            try{
                boolean excluido = RepCliente.excluir(clienteSelecionado.getId());
                if(excluido){
                    JOptionPane.showMessageDialog(this, "Cliente exclu�d com sucesso");
                    clienteSelecionado = null;
                    txtNome.setText("");
                    txtTelefone.setText("");
                    txtSenha.setText("");
                    carregarClientes();
                }else{
                    JOptionPane.showMessageDialog(this, "N�o foi poss�vel excluir o cliente.");
                    
                }
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, "Erro: "+ex.getMessage());
            }
        }
    });
               }

    
    private RepCliente RepCliente = new RepCliente();
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtTelefone;
    private javax.swing.JPasswordField txtSenha;
    private javax.swing.JButton btnSalvar;
    
    private Cliente clienteSelecionado;
    
   
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 770, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 486, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(editarCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(editarCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(editarCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(editarCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                editarCliente dialog = new editarCliente(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    private JTable tabelaClientes;
    private DefaultTableModel modelo;
    private void criarTabela(){
        modelo = new DefaultTableModel(
          new String[]{"ID", "Nome", "Data de Nascimento", "Telefone"},0){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
                tabelaClientes = new JTable(modelo);
                
        JScrollPane scroll = new JScrollPane(tabelaClientes);
        scroll.setBounds(0, 0, 500, 300);
        jPanel1.setLayout(null);
        jPanel1.add(scroll); //duvidas nesse scroll e na parte do layout
    }
    
    public void carregarClientes(){
        try{
            modelo.setRowCount(0);//n�o entendi esse 0 muito bem
            
            List<Cliente> lista = RepCliente.retornar();
           
            if(lista != null){
                for(Cliente c : lista){
                    modelo.addRow(new Object[]{
                        c.getId(),
                        c.getNome(),
                        c.getData_nascimento(),
                        c.getTelefone()
                    });
                }
            }else{
                JOptionPane.showMessageDialog(this, "Erro ao carregar clientes");
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Erro: "+ex.getMessage());//duvida nesses this
            ex.printStackTrace();
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables



}
